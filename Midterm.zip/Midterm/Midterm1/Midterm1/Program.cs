﻿using System;
namespace Midterm1
{
    class MainClass
    {
        double[] price = new double[400];
        char[] selection = new char[400];
        public static void Main(string[] args)
        {
            int i = 0;
            char yesNoDesert;
            char anotherorder;
            char current = 'A';
            double total = 0;
            int track = 0;
            MainClass main = new MainClass();
            do
            {
                // Display Menu
                Console.WriteLine("Welcome to Rigby Restaurant");
                Console.WriteLine("----------------Food---------------");
                Console.WriteLine("Pizza       Chicken(h)   Spaghetti");
                Console.WriteLine(" $20           $15          $25");
                Console.WriteLine("----------------Drinks----------------");
                Console.WriteLine("Sprite(r)        Coke     Mountain Dew");
                Console.WriteLine(" $5              $4           $3");
                Console.WriteLine("---------------Deserts---------------");
                Console.WriteLine("Ice Cream       Pie(e)     Cinnamon Roll(n)");
                Console.WriteLine(" $10             $12          $8");
                // Ask user for food, drink, desert selection
                // Store price in array
                Console.WriteLine("Choose your Food: ");
                current = Convert.ToChar(Console.ReadLine());
                main.selection[track] = current;
                if (current  == 'p')
                {
                    main.price[track] = 20;
                }
                else if(current == 'h')
                {
                    main.price[track] = 15;
                }
                else
                {
                    main.price[track] = 25;
                }
                track += 1;
                Console.WriteLine("Choose your Drink: ");
                current = Convert.ToChar(Console.ReadLine());
                main.selection[track] = current;
                if (current == 'r')
                {
                    main.price[track] = 5;
                }
                else if (current == 'c')
                {
                    main.price[track] = 4;
                }
                else 
                {
                    main.price[track] = 3;
                }
                Console.WriteLine("Do you want Deserts?: ");
                yesNoDesert = Convert.ToChar(Console.ReadLine());
                if (yesNoDesert != 'N' && yesNoDesert != 'n')
                {
                    track += 1;
                    Console.WriteLine("Choose your Deserts: ");
                    current = Convert.ToChar(Console.ReadLine());
                    main.selection[track] = current;
                    if (current == 'i')
                    {
                        main.price[track] = 10;
                    }
                    else if (current == 'e')
                    {
                        main.price[track] = 12;
                    }
                    else
                    {
                        main.price[track] = 8;
                    }
                }
                // Ask if user wants to try the program another time.
                Console.WriteLine("Another Order? (Y/N): ");
                anotherorder = Convert.ToChar(Console.ReadLine());
            }
            // If user wants to try again, the process will be repeated.
            while (anotherorder != 'N' && anotherorder != 'n');
            // Display order with prices
            Console.WriteLine("\nYour order was: ");
            // Assign item to case to be executed
            for (int j = 0; j < main.selection.Length; j++)
            {
                switch (main.selection[j])
                {
                    case 'p':
                        Console.WriteLine("Pizza for " + main.price[j]);
                        break;
                    case 'h':
                        Console.WriteLine("Chicken for " + main.price[j]);
                        break;
                    case 's':
                        Console.WriteLine("Spaghetti for " + main.price[j]);
                        break;
                    case 'r':
                        Console.WriteLine("Sprite for " + main.price[j]);
                        break;
                    case 'c':
                        Console.WriteLine("Coke for " + main.price[j]);
                        break;
                    case 'm':
                        Console.WriteLine("Mountain Dew for " + main.price[j]);
                        break;
                    case 'i':
                        Console.WriteLine("Ice Cream for " + main.price[j]);
                        break;
                    case 'e':
                        Console.WriteLine("Pie for " + main.price[j]);
                        break;
                    case 'n':
                        Console.WriteLine("Cinnamon Roll for " + main.price[j]);
                        break;
                }
                // Compute total
                
                total += main.price[j];
            }
            // Output total
            Console.WriteLine("\nYour total is: $" + total);
            // Generate random number between 1 and 10
            Random rand = new Random();
            int fortunerand = rand.Next(0, 10);
            // Assign fortune cookie quotes to the random numbers from 1 to 10 to be displayed
            switch (fortunerand)
            {
                case 1:
                    Console.WriteLine("\nThe early bird gets the worm, but the second mouse gets the cheese.");
                    Console.WriteLine("\nThanks for dining with us!");
                    break;
                case 2:
                    Console.WriteLine("\nYour road to glory will be rocky, but fulfilling.");
                    Console.WriteLine("\nThanks for dining with us!");
                    break;
                case 3:
                    Console.WriteLine("\nPaitence is your alley at the moment.");
                    Console.WriteLine("\nThanks for dining with us!");
                    break;
                case 4:
                    Console.WriteLine("\nDon't pursue happiness, create it.");
                    Console.WriteLine("\nThanks for dining with us!");
                    break;
                case 5:
                    Console.WriteLine("\nReal kindness comes from within you.");
                    Console.WriteLine("\nThanks for dining with us!");
                    break;
                case 6:
                    Console.WriteLine("\nAll things are difficult before they are easy.");
                    Console.WriteLine("\nThanks for dining with us!");
                    break;
                case 7:
                    Console.WriteLine("\nDon't worry about money, the best things in life are free.");
                    Console.WriteLine("\nThanks for dining with us!");
                    break;
                case 8:
                    Console.WriteLine("\nHe who throws mud loses ground.");
                    Console.WriteLine("\nThanks for dining with us!");
                    break;
                case 9:
                    Console.WriteLine("\nWe must always have old memories and young hope.");
                    Console.WriteLine("\nThanks for dining with us!");
                    break;
                case 10:
                    Console.WriteLine("\nPeople learn little from success, but much from failure.");
                    Console.WriteLine("\nThanks for dining with us!");
                    break;
            }
        }
    }
}